from scispacy.version import VERSION as __version__
