#!/usr/bin/env bash
# Run type checking over the python code.

mypy scispacy --ignore-missing-imports
