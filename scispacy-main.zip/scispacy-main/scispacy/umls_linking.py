# Kept for backward compatability.
from scispacy.linking import EntityLinker as UmlsEntityLinker  # noqa: F401
